/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
 /*package dbconnection;
import java.sql.*;
public class DBConnection {
    private static final String URL = "jdbc:mysql://156.67.76.7:3306/u997807830_softwareConst";
    private static final String USER = "u997807830_SE204";
    private static final String PASSWORD = "SE204softwareconstruction";
    public static Connection connectOnlineDB()
    {
        Connection connection = null; 
        try {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
        System.out.println("Database Connected");
        return connection; 
        } 
        catch (Exception e) {
        System.out.println("Not connected");
        return null;
        }
    }
}
*/
package dbconnection;

import java.sql.*;

public class DBConnection {

    private static final String URL = "jdbc:mysql://156.67.76.7:3306/u997807830_softwareConst";
    private static final String USER = "u997807830_SE204";
    private static final String PASSWORD = "SE204softwareconstruction";

    // Veritabanına bağlanmak için kullanılacak metot
    public static Connection connectOnlineDB() {
        Connection connection = null;
        try {
            // Veritabanı bağlantısı
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database Connected");
            return connection;
        } catch (SQLException e) {
            // Bağlantı hatası durumunda hata mesajı
            System.out.println("Database connection failed.");
            // Hata ayrıntıları
            return null;
        }
    }

    // Bağlantıyı düzgün bir şekilde kapatmak için yardımcı metot
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                System.out.println("Error while closing the database connection.");
                e.printStackTrace();
            }
        }
    }
}
