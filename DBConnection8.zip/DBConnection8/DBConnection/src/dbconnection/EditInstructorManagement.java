/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dbconnection;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.awt.*;
public class EditInstructorManagement extends JFrame {

    Connection con = null;
    Statement st = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private JTextField nameField, surnameField, emailField, lectureField, titleField, passwordField;
    private JButton saveButton;
    private JDialog editDialog;
    private String originalEmail;
    public EditInstructorManagement() {
        initComponents();
        con = DBConnection.connectOnlineDB();
        loadInstructors();
        InstructorList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) 
            {
                int row = InstructorList.rowAtPoint(evt.getPoint());
                int column = InstructorList.columnAtPoint(evt.getPoint());

                if (column == 6) 
                { // Edit ikonu kolon numarası
                    String name = InstructorList.getValueAt(row, 0).toString();
                    String surname = InstructorList.getValueAt(row, 1).toString();
                    String email = InstructorList.getValueAt(row, 2).toString();
                    String lecture = InstructorList.getValueAt(row, 3).toString();
                    String title = InstructorList.getValueAt(row, 4).toString();
                    String password = InstructorList.getValueAt(row, 5).toString();
    
                    openEditDialog(name, surname, email, lecture, title, password); // 3. kolon email
                    JOptionPane.showMessageDialog(null, "Edit Instructor: " + name);
                } 
                else if (column == 7) 
                { // Delete ikonu kolon numarası
                    String name = InstructorList.getValueAt(row, 0).toString();
                    int confirm = JOptionPane.showConfirmDialog(null, "Delete Instructor: " + name + " ?", "Confirm", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) 
                    {
                    try 
                    {
                        String sql = "DELETE FROM instructors WHERE name = ?";
                        pst = con.prepareStatement(sql);
                        pst.setString(1, name);
                        int deleted = pst.executeUpdate(); // Silme işlemi gerçekleşiyor
                        if (deleted > 0) 
                        {
                            JOptionPane.showMessageDialog(null, "Instructor deleted: " + name);
                            loadInstructors(); // Tabloyu güncelle
                        } 
                        else 
                        {
                            JOptionPane.showMessageDialog(null, "Delete failed!");
                        }
                    } 
                    catch (Exception e) 
                    {
                        JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage());
                    }
                }
            }
    }
});
    }
    
        
private void openEditDialog(String name, String surname, String email, String lecture, String title, String password) {
    editDialog = new JDialog(this, "Edit Instructor", true);
    editDialog.setLayout(new GridLayout(7, 2, 10, 10));

    nameField = new JTextField(name, 20);
    surnameField = new JTextField(surname, 20);
    emailField = new JTextField(email, 20);
    lectureField = new JTextField(lecture, 20);
    titleField = new JTextField(title, 20);
    passwordField = new JTextField(password, 20);
    saveButton = new JButton("Save Changes");
    originalEmail = email;

    editDialog.add(new JLabel("Name:")); editDialog.add(nameField);
    editDialog.add(new JLabel("Surname:")); editDialog.add(surnameField);
    editDialog.add(new JLabel("Email:")); editDialog.add(emailField);
    editDialog.add(new JLabel("Lecture:")); editDialog.add(lectureField);
    editDialog.add(new JLabel("Title:")); editDialog.add(titleField);
    editDialog.add(new JLabel("Password:")); editDialog.add(passwordField);
    editDialog.add(new JLabel("")); editDialog.add(saveButton);

    saveButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
            saveChanges();
        }
    });

    editDialog.setSize(300, 250);
    editDialog.setLocationRelativeTo(this);
    editDialog.setVisible(true);
}

private void saveChanges() {
    try {
        String sql = "UPDATE instructors SET name=?, surname=?, mail=?, lecture=?, title=?, password=? WHERE mail=?";
        pst = con.prepareStatement(sql);
        pst.setString(1, nameField.getText());
        pst.setString(2, surnameField.getText());
        pst.setString(3, emailField.getText());
        pst.setString(4, lectureField.getText());
        pst.setString(5, titleField.getText());
        pst.setString(6, passwordField.getText());
        pst.setString(7, originalEmail);

        int updated = pst.executeUpdate();

        if (updated > 0) {
            JOptionPane.showMessageDialog(this, "Instructor updated successfully!");
            editDialog.dispose(); // küçük pencereyi kapat
            loadInstructors(); // tabloyu güncelle
        } else {
            JOptionPane.showMessageDialog(this, "Update failed!");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "ERROR: " + e.getMessage());
    }
}

private void loadInstructors() 
    {
        try 
        {
            String sql = "SELECT name, surname, mail, lecture, title, password FROM instructors"; // admin tablosundan çekiyoruz
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            // Tablo modelini oluşturuyoruz
            DefaultTableModel model = (DefaultTableModel) InstructorList.getModel();
            model.setRowCount(0); // önce eski satırları temizle
            while (rs.next()) 
            {// Her admin için bir satır ekle
                model.addRow(new Object[]{
                rs.getString("name"),
                rs.getString("surname"),
                rs.getString("mail"),
                rs.getString("lecture"),
                rs.getString("title"),
                rs.getString("password"),
                "🖊", // Edit ikonu 
                "⛔"  // Delete ikonu
                });
            }
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        InstructorList = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(122, 178, 203));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 0, 36)); // NOI18N
        jLabel1.setText("OpenCourse");

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 0, 22)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("~ADMIN");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(163, 163, 163)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addContainerGap(269, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(44, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(39, 39, 39))
        );

        InstructorList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "NAME", "SURNAME", "E-MAIL", "LECTURE", "TITLE", "PASSWORD", "🖊", "⛔"
            }
        ));
        jScrollPane1.setViewportView(InstructorList);

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        jButton1.setText("EXIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setText("-Instructor Management-");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(327, 327, 327)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(287, 287, 287)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditInstructorManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditInstructorManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditInstructorManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditInstructorManagement.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditInstructorManagement().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable InstructorList;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
