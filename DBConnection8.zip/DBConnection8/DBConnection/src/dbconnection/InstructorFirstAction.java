/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dbconnection;

import java.sql.*;
import javax.swing.*;
public class InstructorFirstAction extends javax.swing.JFrame {

    Connection con = null;
    Statement st = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private String instructorName;

    public InstructorFirstAction() {
        initComponents();
        con = DBConnection.connectOnlineDB();
        populateCoursesComboBox();
    }
    public InstructorFirstAction(String instructorName) {
        this.instructorName = instructorName;
        initComponents();
        con = DBConnection.connectOnlineDB();
        Lecturesby.setText("Lectures by "+ instructorName);
        populateCoursesComboBox();
        ShowButton.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            String selectedCourse = (String) SelectCourse.getSelectedItem();
            String[] instructorEmails = { instructorName + "@example.com" };
            InstructorsToCourse(selectedCourse, instructorEmails);
        }
    });
    }
private void populateCoursesComboBox() {
        try {
            String sql = "SELECT course_name FROM courses";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            // Önce eski öğeleri temizle
            SelectCourse.removeAllItems();
            while (rs.next()) {
                String name = rs.getString("course_name");
                System.out.println(name);
                SelectCourse.addItem(name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

private void InstructorsToCourse(String courseName, String[] instructorEmails) {
    try {
        // 1. Kurs kodunu bul
        String courseCode = null;
        String sql = "SELECT course_code FROM courses WHERE course_name = ?";
        pst = con.prepareStatement(sql);
        pst.setString(1, courseName);
        rs = pst.executeQuery();
        
        if (rs.next()) {
            courseCode = rs.getString("course_code");
            System.out.println("Bulunan kurs kodu: " + courseCode);
        } else {
            JOptionPane.showMessageDialog(null, "Kurs bulunamadı: " + courseName);
            return;
        }
        
        // 2. Courses tablosundan kurs bilgilerini al
        String checkQuery = "SELECT mail FROM courses WHERE course_code = ?";
        pst = con.prepareStatement(checkQuery);
        pst.setString(1, courseCode);
        rs = pst.executeQuery();
        
        if (rs.next()) {
            String existingMails = rs.getString("mail");
            
            // Eğer öğretmen zaten bu kursa atanmışsa uyarı ver
            boolean alreadyAssigned = false;
            for (String mail : instructorEmails) {
                if (existingMails != null && existingMails.contains(mail)) {
                    alreadyAssigned = true;
                    JOptionPane.showMessageDialog(null, 
                        "Bu öğretmen (" + mail + ") zaten bu kursa (" + courseName + ") atanmış!");
                    break;
                }
            }
            
            if (!alreadyAssigned) {
                // 3. Courses tablosunda mail alanını güncelle
                String updateSql = "UPDATE courses SET mail = ? WHERE course_code = ?";
                pst = con.prepareStatement(updateSql);
                
                // Mevcut e-postaları yeni e-posta ile birleştir
                String newMails = "";
                if (existingMails != null && !existingMails.isEmpty()) {
                    newMails = existingMails;
                    for (String mail : instructorEmails) {
                        newMails += "," + mail;
                    }
                } else {
                    newMails = String.join(",", instructorEmails);
                }
                
                pst.setString(1, newMails);
                pst.setString(2, courseCode);
                pst.executeUpdate();
                
                JOptionPane.showMessageDialog(null, "Öğretmenler başarıyla kursa atandı!");
            }
        } else {
            // Kurs var ama mail alanı yoksa veya boşsa, ilk kez atama yapılıyor
            String updateSql = "UPDATE courses SET mail = ? WHERE course_code = ?";
            pst = con.prepareStatement(updateSql);
            String newMails = String.join(",", instructorEmails);
            pst.setString(1, newMails);
            pst.setString(2, courseCode);
            int affected = pst.executeUpdate();
            
            if (affected > 0) {
                JOptionPane.showMessageDialog(null, "Öğretmenler başarıyla kursa atandı!");
            } else {
                JOptionPane.showMessageDialog(null, "Atama yapılamadı. Kurs bulunamadı.");
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Hata oluştu: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Lecturesby = new javax.swing.JLabel();
        ShowButton = new javax.swing.JButton();
        SelectCourse = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(122, 178, 203));

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 0, 36)); // NOI18N
        jLabel1.setText("OpenCourse");

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 0, 22)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("~INSTRUCTOR");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jButton1.setBackground(new java.awt.Color(204, 204, 204));
        jButton1.setFont(new java.awt.Font("Helvetica Neue", 0, 20)); // NOI18N
        jButton1.setText("EXIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Lecturesby.setFont(new java.awt.Font("Helvetica Neue", 0, 25)); // NOI18N
        Lecturesby.setText("Lectures by");

        ShowButton.setBackground(new java.awt.Color(184, 222, 210));
        ShowButton.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        ShowButton.setText("SHOW");
        ShowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowButtonActionPerformed(evt);
            }
        });

        SelectCourse.setFont(new java.awt.Font("Helvetica Neue", 0, 19)); // NOI18N
        SelectCourse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        SelectCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectCourseActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 0, 25)); // NOI18N
        jLabel3.setText("Select Course");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(41, 41, 41))
                            .addComponent(SelectCourse, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addComponent(Lecturesby))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(ShowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addComponent(jButton1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jLabel3)
                .addGap(39, 39, 39)
                .addComponent(SelectCourse, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(Lecturesby)
                .addGap(49, 49, 49)
                .addComponent(ShowButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(53, 53, 53))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ShowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowButtonActionPerformed
        // TODO add your handling code here:
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShowCourseOfInstructor().setVisible(true);
            }
        });

    }//GEN-LAST:event_ShowButtonActionPerformed

    private void SelectCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectCourseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelectCourseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InstructorFirstAction.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InstructorFirstAction.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InstructorFirstAction.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InstructorFirstAction.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InstructorFirstAction().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Lecturesby;
    private javax.swing.JComboBox<String> SelectCourse;
    private javax.swing.JButton ShowButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
