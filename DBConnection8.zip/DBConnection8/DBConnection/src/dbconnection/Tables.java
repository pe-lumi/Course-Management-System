/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dbconnection;
import java.sql.*;
public class Tables {
    Connection con = null;
    Statement st = null;
    public void resetStudentTable() {
    Connection con = null;
    Statement st = null;
    try {
        con = DBConnection.connectOnlineDB();
        if (con == null) {
            System.out.println("Database not connected!");
            return;
        }
        
        st = con.createStatement();
        
        // Önce tabloyu siliyoruz
        st.executeUpdate("DROP TABLE IF EXISTS students");
        //System.out.println("Courses tablosu silindi.");
        
        // Sonra tekrar oluşturuyoruz
        String createStudents = """
        CREATE TABLE IF NOT EXIST Group8_courses ( id INT AUTO_INCREMENT PRIMARY KEY,  first_name VARCHAR(100),last_name VARCHAR(100),p_email VARCHAR(100), ins_email VARCHAR(100) UNIQUE,faculty VARCHAR(100),department VARCHAR(100),password VARCHAR(255));""";
        st.executeUpdate(createStudents);
        //System.out.println("Courses tablosu başarıyla yeniden oluşturuldu!");
        
    } catch(Exception e) {
        System.out.println("ERROR table: " + e.getMessage());
        e.printStackTrace();
    } finally {
        // Kaynakları serbest bırak
        try {
            if (st != null) st.close();
            if (con != null) con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
public void resetCoursesTable() {
    Connection con = null;
    Statement st = null;
    try {
        con = DBConnection.connectOnlineDB();
        if (con == null) {
            System.out.println("Database not connected!");
            return;
        }
        
        st = con.createStatement();
        
        // Önce tabloyu siliyoruz
        st.executeUpdate("DROP TABLE IF EXISTS courses");
        System.out.println("Courses tablosu silindi.");
        
        // Sonra tekrar oluşturuyoruz
        String createCourses = """
        CREATE TABLE IF NOT EXIST Group8_courses (course_name VARCHAR(200), course_code VARCHAR(20) UNIQUE, instructor VARCHAR(200), credit INT);""";
        st.executeUpdate(createCourses);
        System.out.println("Courses tablosu başarıyla yeniden oluşturuldu!");
        
    } catch(Exception e) {
        System.out.println("Courses tablosu sıfırlama hatası: " + e.getMessage());
        e.printStackTrace();
    } finally {
        // Kaynakları serbest bırak
        try {
            if (st != null) st.close();
            if (con != null) con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
    public void CreateTables() {
        try {
            // Her seferinde yeni bağlantı al
            con = DBConnection.connectOnlineDB();
            if (con == null) {
                System.out.println("Database not connected!");
                return;
            }
            
            // Öğrenci tablosunu oluştur
            String students = """
            CREATE TABLE IF NOT EXISTS Group8_students ( id INT AUTO_INCREMENT PRIMARY KEY, first_name VARCHAR(100), last_name VARCHAR(100), p_email VARCHAR(100), ins_email VARCHAR(100) UNIQUE, faculty VARCHAR(100),   department VARCHAR(100), password VARCHAR(255) );""";
            
            st = con.createStatement();
            st.executeUpdate(students);
            
            // Öğretim görevlisi tablosu
            String instructors = """
            CREATE TABLE IF NOT EXISTS Group8_instructors ( id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),surname VARCHAR(100),mail VARCHAR(100) UNIQUE, lecture VARCHAR(100), title VARCHAR(100),password VARCHAR(255));""";
            
            st.executeUpdate(instructors);
            
            String admins = """
            CREATE TABLE IF NOT EXISTS Group8_ admins ( id INT AUTO_INCREMENT PRIMARY KEY,  name VARCHAR(100), surname VARCHAR(100), mail VARCHAR(100) UNIQUE,  password VARCHAR(255) );""";
            
            st.executeUpdate(admins);
            
            // Kurs tablosu
            /*String courses = """
            CREATE TABLE IF NOT EXISTS courses (
  
                course_name VARCHAR(200),
                course_code VARCHAR(20) UNIQUE,
                instructor VARCHAR(200),
                credit INT
            );""";*/
            
            String courses = """
            CREATE TABLE IF NOT EXISTS Group8_courses ( course_name VARCHAR(200),course_code VARCHAR(20) UNIQUE,instructor VARCHAR(200),credit INT, mail TEXT);""";
            st.executeUpdate(courses);
            
            String course_instructors = """
            CREATE TABLE IF NOT EXISTS Group8_ course_instructors ( course_code VARCHAR(50) NOT NULL, instructor_email VARCHAR(255) NOT NULL,PRIMARY KEY (course_code, instructor_email),FOREIGN KEY (course_code) REFERENCES courses(course_code), FOREIGN KEY (instructor_email) REFERENCES instructors(mail) );""";
            
            String StudentList = """
    CREATE TABLE IF NOT EXISTS Group8_student_logins (ID INT(5) PRIMARY KEY,Name VARCHAR(150), Department VARCHAR(100),Faculty VARCHAR(100), Age INT(3), DOB DATE, email VARCHAR(100) UNIQUE, password VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP );""";
st.executeUpdate(StudentList);
            
        String selectedCourses = """
            CREATE TABLE IF NOT EXISTS Group8_selected_courses ( student_email VARCHAR(100), course_name VARCHAR(200), PRIMARY KEY (student_email, course_name), FOREIGN KEY (student_email) REFERENCES students(p_email),FOREIGN KEY (course_name) REFERENCES courses(course_name));""";
            st.executeUpdate(selectedCourses);


            System.out.println("Tüm tablolar başarıyla oluşturuldu!");
            
        } catch(Exception e) {
            System.out.println("Tablo oluşturma hatası: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Kaynakları serbest bırak
            try {
                if (st != null) st.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String[] args) {
    Tables tables = new Tables();
    
    // Tabloları oluşturmak istiyorsan:
    tables.CreateTables();
    
    // Öğrenci tablosunu sıfırlamak istiyorsan:
    // tables.resetStudentTable();
    
    // Kurs tablosunu sıfırlamak istiyorsan:
    // tables.resetCoursesTable();
}

}
